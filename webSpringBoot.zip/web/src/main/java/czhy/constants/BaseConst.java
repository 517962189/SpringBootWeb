package czhy.constants;

import lombok.Data;

@Data
public class BaseConst {

    //分页常量
    public static final Long PAGE = 1L;
    public static final Long SIZE = 10L;
}
