package czhy.constants;

import lombok.Data;

@Data
public class UserConst {
    //默认用户名
    public static final String DEFAULT_ADMIN_NAME = "system";

}
