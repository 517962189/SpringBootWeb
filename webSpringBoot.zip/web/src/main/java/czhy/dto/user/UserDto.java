package czhy.dto.user;

import lombok.Data;

@Data
public class UserDto {
    private String uuid;
}
