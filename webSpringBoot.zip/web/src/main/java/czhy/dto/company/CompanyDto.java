package czhy.dto.company;

public class CompanyDto {
}
